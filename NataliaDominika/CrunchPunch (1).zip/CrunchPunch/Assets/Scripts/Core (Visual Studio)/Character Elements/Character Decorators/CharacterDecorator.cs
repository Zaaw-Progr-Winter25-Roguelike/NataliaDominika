using System;
using UnityEngine;

public class CharacterDecorator : Character
{
    protected Character baseCharacter;
    public CharacterDecorator(Character c)
    {
        baseCharacter = c ?? throw new ArgumentNullException(nameof(c));
    }
   
    public Character GetBaseCharacter()
    {
        return baseCharacter;
    }

    public void SetBaseCharacter(Character c)
    {
        baseCharacter = c;
    }


    public override int HP
    {
        get => baseCharacter.HP;
        set => baseCharacter.HP = value;
    }
    public override int MP
    {
        get => baseCharacter.MP;
        set => baseCharacter.MP = value;
    }
    public override int XP
    {
        get => baseCharacter.XP;
        set => baseCharacter.XP = value;
    }
    public override string ClassName
    {
        get => baseCharacter.ClassName;
        set => baseCharacter.ClassName = value;
    }


    public override void AttachObserver(IStatsObserver observer) => baseCharacter.AttachObserver(observer);
    public override void Notify(string eventType) => baseCharacter.Notify(eventType);

    public override void GainXP(int amount) => baseCharacter.GainXP(amount);
    public override void TakeDamage(int dmg) => baseCharacter.TakeDamage(dmg);
    public override void AddHP(int amount) => baseCharacter.AddHP(amount);
    public override bool UseMana(int amount) => baseCharacter.UseMana(amount);
    public override void AddMP(int amount) => baseCharacter.AddMP(amount);
    public override void SetStrategy(ICombatStrategy newStrategy) => baseCharacter.SetStrategy(newStrategy);

    public override int PerformAttack()
    {
        return baseCharacter.PerformAttack();
    }

    public override void DisplayClass() => baseCharacter.DisplayClass();
    public override void OnTick() => baseCharacter.OnTick();
}