using UnityEngine;

public class FrenzyMode : CharacterDecorator
{
    public FrenzyMode(Character c) : base(c) { }

    public override int PerformAttack()
    {
        int baseDamage = baseCharacter.PerformAttack();

        if (baseDamage > 0)
        {
            int frenzyDamage = baseDamage * 2; 
            Debug.Log($"<color=red>SZA�! {baseDamage} -> {frenzyDamage}</color>");
            return frenzyDamage;
        }
        return 0;
    }
}