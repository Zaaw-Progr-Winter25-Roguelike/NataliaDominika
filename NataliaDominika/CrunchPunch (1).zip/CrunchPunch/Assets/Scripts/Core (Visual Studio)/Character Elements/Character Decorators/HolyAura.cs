using UnityEngine;

public class HolyAura : CharacterDecorator
{
    private float nextHealTime = 0f;
    private float healInterval = 1.0f; 

    public HolyAura(Character c) : base(c)
    {
        nextHealTime = Time.time + healInterval;
    }

    public override void OnTick()
    {
        base.OnTick();

        if (Time.time >= nextHealTime)
        {
            int healAmount = 5; 
            baseCharacter.AddHP(healAmount);
            Debug.Log($"[HOLY AURA] Uleczono {healAmount} HP");

            nextHealTime = Time.time + healInterval;
        }
    }

    public override void DisplayClass()
    {
        base.DisplayClass();
        Debug.Log("+ �wi�ta Aura (Leczenie HP)");
    }
}