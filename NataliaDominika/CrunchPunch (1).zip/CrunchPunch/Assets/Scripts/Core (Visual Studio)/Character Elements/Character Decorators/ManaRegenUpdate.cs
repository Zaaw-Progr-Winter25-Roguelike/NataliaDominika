using UnityEngine;

public class ManaRegenUpdate : CharacterDecorator
{
    private float nextRegenTime = 0f;
    private float regenInterval = 1.0f; 

    public ManaRegenUpdate(Character c) : base(c)
    {
        nextRegenTime = Time.time + regenInterval;
    }

    public override void OnTick()
    {
        base.OnTick();

        if (Time.time >= nextRegenTime)
        {
            int manaAmount = 3; 
            AddMP(manaAmount);
            Debug.Log($"[MANA] +{manaAmount} MP");

            nextRegenTime = Time.time + regenInterval;
        }
    }

    public override void DisplayClass()
    {
        base.DisplayClass();
        Debug.Log("+ Regeneracja Many");
    }
}