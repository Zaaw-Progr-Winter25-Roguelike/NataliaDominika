using System;

public class BeastmasterFactory : CharacterFactory
{
    public override Character CreateCharacter(string subtype)
    {
        return subtype.ToLower() switch
        {
            "wolftamer" => new WolfTamer(),
            "serpentwhisperer" => new SerpentWhisperer(),
            "dragoncaller" => new DragonCaller(),

            _ => throw new Exception("Unknown beastmaster subtype.")
        };
    }
}
