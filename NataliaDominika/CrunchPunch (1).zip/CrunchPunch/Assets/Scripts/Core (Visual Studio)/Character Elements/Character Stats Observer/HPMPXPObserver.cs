using UnityEngine;

public class HPMPXPObserver : IStatsObserver
{
    public void OnStatsChanged(Character c, string eventType)
    {
        string message = eventType switch
        {
            "DEAD" => "Umar�e�!",
            "HP_CHANGED" => $"{c.ClassName} HP: {c.HP}",
            "XP_CHANGED" => $"{c.ClassName} XP: {c.XP}",
            "MP_CHANGED" => $"{c.ClassName} MP: {c.MP}",
            _ => null
        };

        if (message != null)
            Debug.Log(message);
    }
}

