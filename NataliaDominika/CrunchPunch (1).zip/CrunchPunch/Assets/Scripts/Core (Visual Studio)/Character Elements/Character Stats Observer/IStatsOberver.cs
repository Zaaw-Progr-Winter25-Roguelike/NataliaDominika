public interface IStatsObserver
{
    void OnStatsChanged(Character c, string eventType);
}

