public interface ICombatStrategy
{
    // Zmieniamy void na int (zwraca ilo�� obra�e�)
    int ExecuteAttack(Character c);
}