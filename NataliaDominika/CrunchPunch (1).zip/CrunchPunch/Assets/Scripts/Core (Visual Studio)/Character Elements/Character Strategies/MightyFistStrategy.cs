using UnityEngine;

public class MightyFistStrategy : ICombatStrategy
{
    public int ExecuteAttack(Character c)
    {
        int manaCost = 15;
        int damage = 20;

        if (c.UseMana(manaCost))
        {
            Debug.Log($"[ATAK] Mighty Fist! (-{manaCost} MP, {damage} DMG)");
            return damage;
        }
        else
        {
            Debug.Log("[B��D] Za ma�o many na Mighty Fist!");
            return 0; // Brak ataku
        }
    }
}