using UnityEngine;

public class SmokeScreenStrategy : ICombatStrategy
{
    public int ExecuteAttack(Character c)
    {
        int manaCost = 10;
        int healAmount = 20; 

        if (c.UseMana(manaCost))
        {
            c.HP += healAmount;

            if (c.HP > 100) c.HP = 100;

            Debug.Log($"[OBRONA] Smoke Screen! Ukry�e� si� i odnowi�e� {healAmount} HP! (-{manaCost} MP)");

            return 0;
        }
        else
        {
            Debug.Log("[B��D] Za ma�o many na Smoke Screen!");
            return 0;
        }
    }
}