using UnityEngine;

public class SwiftBladeStrategy : ICombatStrategy
{
    public int ExecuteAttack(Character c)
    {
        int manaCost = 5;
        int damage = 5; 

        if (c.UseMana(manaCost))
        {
            Debug.Log($"[ATAK] Swift Blade! (-{manaCost} MP, {damage} DMG)");
            return damage;
        }
        else
        {
            Debug.Log("[B��D] Za ma�o many na Swift Blade!");
            return 0;
        }
    }
}