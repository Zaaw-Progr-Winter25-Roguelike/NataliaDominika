using UnityEngine;

public class Beastmaster : Character
{
    public override void DisplayClass()
    {
        Debug.Log("Klasa: Beastmaster");
    }
}

