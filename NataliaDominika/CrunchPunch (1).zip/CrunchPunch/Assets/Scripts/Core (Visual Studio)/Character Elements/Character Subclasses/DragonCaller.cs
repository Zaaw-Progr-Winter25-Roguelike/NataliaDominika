using UnityEngine;

public class DragonCaller : Beastmaster
{
    public DragonCaller()
    {
        ClassName = "DragonCaller";
    }

    public override void DisplayClass()
    {
        Debug.Log("Posta�: Dragon Caller");
    }
}
