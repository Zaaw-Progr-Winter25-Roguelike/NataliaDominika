using UnityEngine;

public class SerpentWhisperer : Beastmaster
{
    public SerpentWhisperer()
    {
        ClassName = "SerpentWhisperer";
    }

    public override void DisplayClass()
    {
        Debug.Log("Posta�: Serpent Whisperer");
    }
}

