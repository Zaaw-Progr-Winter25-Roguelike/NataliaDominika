using UnityEngine;
public class WolfTamer : Beastmaster
{
    public WolfTamer()
    {
        ClassName = "WolfTamer";
    }

    public override void DisplayClass()
    {
        Debug.Log("Posta�: Wolf Tamer");
    }
}

