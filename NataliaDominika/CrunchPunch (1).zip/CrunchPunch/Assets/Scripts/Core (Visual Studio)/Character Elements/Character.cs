using System.Collections.Generic;
using UnityEngine;

public abstract class Character
{
    public virtual int HP { get; set; } = 100;
    public virtual int MP { get; set; } = 50;
    public virtual int XP { get; set; } = 0;

    protected List<IStatsObserver> observers = new();
    protected ICombatStrategy strategy;

    public virtual string ClassName { get; set; }

    public virtual void SetStrategy(ICombatStrategy newStrategy)
    {
        strategy = newStrategy;
    }

    public virtual void AttachObserver(IStatsObserver observer)
    {
        observers.Add(observer);
    }

    public virtual void Notify(string eventType)
    {
        foreach (var obs in observers)
        {
            obs.OnStatsChanged(this, eventType);
        }
    }

    public virtual void GainXP(int amount)
    {
        XP += amount;
        Notify("XP_CHANGED");
    }

    public virtual void TakeDamage(int dmg)
    {
        HP -= dmg;
        Notify("HP_CHANGED");

        if (HP <= 0)
        {
            Notify("DEAD");
        }
    }

    public virtual void AddHP(int amount)
    {
        HP += amount;
        Notify("HP_CHANGED");
    }

    public virtual bool UseMana(int amount)
    {
        if (MP >= amount)
        {
            MP -= amount;
            Notify("MP_CHANGED");
            return true; 
        }
        else
        {
            Debug.Log(">>> NO MANA :0! <<<");
            return false; 
        }
    }

    public virtual void AddMP(int amount)
    {
        MP += amount;
        Notify("MP_CHANGED");
    }
    public virtual int PerformAttack()
    {
        if (strategy != null)
        {
            return strategy.ExecuteAttack(this);
        }
        else
        {
            Debug.LogWarning("Posta� nie ma wybranej strategii!");
            return 0;
        }
    }

    public virtual void OnTick()
    {
       
    }

    public abstract void DisplayClass();
}
