using UnityEngine;

public class PlayableCharacter : Character
{
    public PlayableCharacter(string name, int startHP, int startMP)
    {
        ClassName = name;
        HP = startHP;
        MP = startMP;
        XP = 0;
    }

    public override void DisplayClass()
    {
        Debug.Log("Posta� Gracza: " + ClassName);
    }
}