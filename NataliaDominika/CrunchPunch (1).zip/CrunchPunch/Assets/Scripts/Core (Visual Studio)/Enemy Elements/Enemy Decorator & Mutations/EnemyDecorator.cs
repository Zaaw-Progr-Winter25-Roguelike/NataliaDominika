public class EnemyDecorator : Enemy
{
    protected Enemy baseEnemy;

    public EnemyDecorator(Enemy e)
    {
        baseEnemy = e;
    }

    public override void Display() => baseEnemy.Display();

    public override void PerformAction() => baseEnemy.PerformAction();
}
