using UnityEngine;

public class EnragedMutation : EnemyDecorator
{
    public EnragedMutation(Enemy e) : base(e)
    {
        baseEnemy.AddHP(20);
    }

    public override void PerformAction()
    {
        Debug.Log("[ENRAGED MODE] zwi�kszone obra�enia");
        base.PerformAction();
    }

    public override void Display()
    {
        base.Display();
        Debug.Log("+ Mutacja: Enraged");
    }
}

