using UnityEngine;

public class FrozenMutation : EnemyDecorator
{
    public FrozenMutation(Enemy e) : base(e)
    {
        baseEnemy.AddHP(40);
    }

    public override void Display()
    {
        base.Display();
        Debug.Log("+ Mutacja: Frozen");
    }
}
