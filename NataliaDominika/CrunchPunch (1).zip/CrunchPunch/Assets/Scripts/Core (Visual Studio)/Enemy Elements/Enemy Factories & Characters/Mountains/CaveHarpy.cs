using UnityEngine;

public class CaveHarpy : Enemy
{
    public CaveHarpy()
    {
        EnemyName = "Cave Harpy";
        HP = 60;

        behavior = new DeafeningScreechBehavior();

        LootDrop = new Eyeball();
        DropChance = 70;
    }

    public override void Display()
    {
        Debug.Log("Przeciwnik: Cave Harpy");
    }
}

