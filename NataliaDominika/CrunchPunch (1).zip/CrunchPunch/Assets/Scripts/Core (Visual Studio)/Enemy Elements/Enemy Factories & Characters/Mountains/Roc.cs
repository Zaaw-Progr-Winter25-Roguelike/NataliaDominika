using UnityEngine;

public class Roc : Enemy
{
    public Roc()
    {
        EnemyName = "Roc";
        HP = 55;

        behavior = new AgressiveDiveBehavior();

        LootDrop = new Feathers();
        DropChance = 45;
    }

    public override void Display()
    {
        Debug.Log("Przeciwnik: Roc");
    }
}

