using UnityEngine;

public class StonehideTroll : Enemy
{
    public StonehideTroll()
    {
        EnemyName = "Stonehide Troll";
        HP = 35;

        behavior = new MassCrusherBehavior();

        LootDrop = new RuneStone();
        DropChance = 85;
    }

    public override void Display()
    {
        Debug.Log("Przeciwnik: Stonehide Troll");
    }
}
