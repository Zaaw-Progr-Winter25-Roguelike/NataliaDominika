using UnityEngine;

public class MossGoblin : Enemy
{
    public MossGoblin()
    {
        EnemyName = "Moss Goblin";
        HP = 90;

        behavior = new DirtBomsThrowBehavior();

        LootDrop = new Worms();
        DropChance = 60;
    }

    public override void Display()
    {
        Debug.Log("Przeciwnik: Moss Goblin");
    }
}

