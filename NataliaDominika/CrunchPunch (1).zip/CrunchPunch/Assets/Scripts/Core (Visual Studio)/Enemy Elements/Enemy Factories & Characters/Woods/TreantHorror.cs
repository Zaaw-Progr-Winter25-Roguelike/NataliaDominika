using UnityEngine;

public class TreantHorror : Enemy
{
    public TreantHorror()
    {
        EnemyName = "Treant Horror";
        HP = 85;

        behavior = new RootSuffocationBehavior();

        LootDrop = new RootCore();
        DropChance = 50;
    }

    public override void Display()
    {
        Debug.Log("Przeciwnik: Treant Horror");
    }
}

