using UnityEngine;

public class Werewolf : Enemy
{
    public Werewolf()
    {
        EnemyName = "Werewolf";
        HP = 70;

        behavior = new ClawScratchBehavior();

        LootDrop = new Fangs();
        DropChance = 70;
    }

    public override void Display()
    {
        Debug.Log("Przeciwnik: Werewolf");
    }
}

