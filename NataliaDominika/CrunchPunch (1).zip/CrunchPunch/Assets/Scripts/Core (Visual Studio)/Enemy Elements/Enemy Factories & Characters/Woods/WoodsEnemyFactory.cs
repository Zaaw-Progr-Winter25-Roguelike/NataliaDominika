using System;

public class WoodsEnemyFactory : EnemyFactory
{
    public override Enemy CreateEnemy(string subtype)
    {
        return subtype.ToLower() switch
        {
            "treanthorror" => new TreantHorror(),
            "mossgoblin" => new MossGoblin(),
            "werewolf" => new Werewolf(),
            _ => throw new Exception("Unknown woods enemy type.")
        };
    }
}

