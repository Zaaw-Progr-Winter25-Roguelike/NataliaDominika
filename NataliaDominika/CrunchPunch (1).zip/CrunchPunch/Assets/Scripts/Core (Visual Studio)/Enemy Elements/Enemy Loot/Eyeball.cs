public class Eyeball : ILoot
{
    public string Name => "Eyeball";
    public int Value => 25;
    public int XP => 10;
}