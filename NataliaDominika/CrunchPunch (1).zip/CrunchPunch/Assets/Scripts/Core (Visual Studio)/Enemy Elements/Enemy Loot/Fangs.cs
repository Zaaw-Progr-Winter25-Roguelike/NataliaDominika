public class Fangs : ILoot
{
    public string Name => "Fangs";
    public int Value => 10;
    public int XP => 10;
}