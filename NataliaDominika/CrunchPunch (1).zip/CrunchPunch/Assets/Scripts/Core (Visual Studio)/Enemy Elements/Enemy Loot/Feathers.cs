public class Feathers : ILoot
{
    public string Name => "Feathers";
    public int Value => 15;
    public int XP => 10;
}