public interface ILoot
{
    string Name { get; }
    int Value { get; }
    int XP { get; } 
}