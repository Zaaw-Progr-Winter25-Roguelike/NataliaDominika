public class RootCore : ILoot
{
    public string Name => "Root Core";
    public int Value => 50;
    public int XP => 10;
}