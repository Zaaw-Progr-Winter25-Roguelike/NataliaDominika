public class RuneStone : ILoot
{
    public string Name => "Rune Stone";
    public int Value => 7;
    public int XP => 10;
}