public class Worms : ILoot
{
    public string Name => "Worms";
    public int Value => 30;
    public int XP => 10;
}