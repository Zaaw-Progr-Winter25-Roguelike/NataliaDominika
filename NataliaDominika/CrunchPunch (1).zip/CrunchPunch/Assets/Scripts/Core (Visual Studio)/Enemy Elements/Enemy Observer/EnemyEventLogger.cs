using UnityEngine;

public class EnemyEventLogger : IEnemyObserver
{
    public void OnEnemyEvent(Enemy e, string eventType)
    {
        switch (eventType)
        {
            case "DEAD":
                Debug.Log($"{e.EnemyName} zosta� pokonany! Otrzymujesz: {e.LootDrop.Name}");
                break;

            case "HP_CHANGED":
                Debug.Log($"{e.EnemyName} HP: {e.HP}");
                break;
        }
    }
}
