public interface IEnemyObserver
{
    void OnEnemyEvent(Enemy enemy, string eventType);
}
