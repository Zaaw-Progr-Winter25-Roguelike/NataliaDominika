using UnityEngine;
public class AgressiveDiveBehavior : IEnemyBehavior
{
    public void ExecuteBehavior()
    {
        Debug.Log("<color=blue>SWIPE!</color>Roc swipes you off your feet with his aggressive dive.");
    }
}

