using UnityEngine;

public class AttackState : IEnemyState
{
    private float attackCooldown = 2.0f; // Czas mi�dzy atakami
    private float cooldownTimer = 0f;

    public void Enter(Enemy enemy)
    {
        if (enemy.Controller != null) enemy.Controller.StopMoving();
    }

    public void Update(Enemy enemy)
    {
        if (enemy.DistanceToPlayer > 1.8f) 
        {
            enemy.ChangeState(new ChaseState());
            return;
        }

        cooldownTimer -= Time.deltaTime;

        if (cooldownTimer <= 0f)
        {
            if (enemy.Controller != null)
            {
                enemy.Controller.PerformAttack(); 
            }
            cooldownTimer = attackCooldown;
        }
    }

    public void Exit(Enemy enemy) { }
}