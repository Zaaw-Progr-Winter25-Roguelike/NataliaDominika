using UnityEngine;

public class ChaseState : IEnemyState
{
    public void Enter(Enemy enemy)
    {
   
    }

    public void Update(Enemy enemy)
    {
        if (enemy.HP < 30)
        {
            enemy.ChangeState(new FleeState());
            return;
        }

        if (enemy.DistanceToPlayer < 1.5f) 
        {
            enemy.ChangeState(new AttackState());
            return;
        }

        if (enemy.Controller != null)
        {
            enemy.Controller.MoveTowardsPlayer();
        }
    }

    public void Exit(Enemy enemy)
    {
        if (enemy.Controller != null) enemy.Controller.StopMoving();
    }
}