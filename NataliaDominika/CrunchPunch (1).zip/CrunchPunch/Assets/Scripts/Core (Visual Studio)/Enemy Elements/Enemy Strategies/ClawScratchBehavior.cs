using UnityEngine;
public class ClawScratchBehavior : IEnemyBehavior
{
    public void ExecuteBehavior()
    {
        Debug.Log("<color=yellow>SLASH!</color>Werewolf slices your skin open with their sharp claws.");
    }
}