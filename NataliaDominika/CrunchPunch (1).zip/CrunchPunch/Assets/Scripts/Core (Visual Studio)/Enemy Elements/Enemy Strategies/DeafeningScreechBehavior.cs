using UnityEngine;
public class DeafeningScreechBehavior : IEnemyBehavior
{
    public void ExecuteBehavior()
    {
        Debug.Log("<color=red>SCREECH!</color>Cave Harpy deafens you with her high pitch screech.");
    }
}
