using UnityEngine;
public class DirtBomsThrowBehavior : IEnemyBehavior
{
    public void ExecuteBehavior()
    {
        Debug.Log("<color=white>BOOM!</color>Moss goblin throws toxic dirt bombs at you.");
    }
}
