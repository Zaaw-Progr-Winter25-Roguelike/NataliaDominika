using UnityEngine;

public class FleeState : IEnemyState
{
    public void Enter(Enemy enemy) { Debug.Log("Uciekam!"); }

    public void Update(Enemy enemy)
    {
        if (enemy.Controller != null)
        {
            enemy.Controller.RunAwayFromPlayer();
        }

        if (enemy.HP <= 0) return; 
    }
    public void Exit(Enemy enemy) { }
}