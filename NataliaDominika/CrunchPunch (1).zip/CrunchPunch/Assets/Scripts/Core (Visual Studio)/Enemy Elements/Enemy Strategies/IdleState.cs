using UnityEngine;

public class IdleState : IEnemyState
{
    public void Enter(Enemy enemy) { if (enemy.Controller) enemy.Controller.StopMoving(); }

    public void Update(Enemy enemy)
    {
        if (enemy.DistanceToPlayer < 4f)
        {
            enemy.ChangeState(new ChaseState());
        }
    }
    public void Exit(Enemy enemy) { }
}