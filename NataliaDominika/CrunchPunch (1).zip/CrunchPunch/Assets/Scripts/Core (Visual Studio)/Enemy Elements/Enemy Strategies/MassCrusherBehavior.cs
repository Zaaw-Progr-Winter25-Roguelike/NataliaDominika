using System;
public class MassCrusherBehavior : IEnemyBehavior
{
    public void ExecuteBehavior()
    {
        Console.WriteLine("<color=green>STRIKE!</color>The Stonehide Troll strikes the opponent with its sword.");
    }
}
