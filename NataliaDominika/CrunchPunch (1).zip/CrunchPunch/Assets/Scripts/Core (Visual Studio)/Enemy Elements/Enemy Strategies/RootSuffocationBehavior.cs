using System;
public class RootSuffocationBehavior : IEnemyBehavior
{
    public void ExecuteBehavior()
    {
        Console.WriteLine("<color=pink>SUFFOCATE!</color>Treant Horror suffocates you with his root.");
    }
}
