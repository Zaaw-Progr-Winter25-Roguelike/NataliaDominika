using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossWave : WaveComposite
{
    public BossWave(EnemyFactory factory)
    {
        var boss = factory.CreateEnemy("drowned man");
        Add(new EnemyLeaf(boss));

        for (int i = 0; i < 3; i++)
            Add(new EnemyLeaf(factory.CreateEnemy("toad")));
    }
}
