using System.Collections;
using System.Collections.Generic;
using UnityEngine;

internal class EliteWave : WaveComposite
{
    public EliteWave(EnemyFactory factory)
    {
        var elite = factory.CreateEnemy("witch");
        elite = new EnragedMutation(elite);
        Add(new EnemyLeaf(elite));
    }
}
