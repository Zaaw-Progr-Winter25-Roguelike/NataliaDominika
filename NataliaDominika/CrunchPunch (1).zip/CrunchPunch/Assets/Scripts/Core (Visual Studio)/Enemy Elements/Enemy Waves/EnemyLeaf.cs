using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Input;
using UnityEngine;

public class EnemyLeaf : IWaveComponent
{
    public Enemy Enemy { get; private set; }

    public EnemyLeaf(Enemy enemy)
    {
        Enemy = enemy;
    }
    public void Spawn()
    {
        Console.WriteLine($"Spawn -> {Enemy.EnemyName}");
        Enemy.Display();
    }

    public void ExecuteCommand(ICommand command)
    {
        command.Execute(Enemy);
    }
    public void UpdateStates()
    {
        Enemy.UpdateState();
    }

    public void ScaleDifficulty(float factor)
    {
        // Zwi�kszamy HP przeciwnika w zale�no�ci od wsp�czynnika
        Enemy.AddHP((int)(Enemy.HP * (factor - 1)));
    }
}
