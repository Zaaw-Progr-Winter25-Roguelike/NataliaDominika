using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IWaveComponent
{
    void Spawn();
    void ExecuteCommand(ICommand command);
    void UpdateStates();
    void ScaleDifficulty(float factor);
}
