using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NormalWave : WaveComposite
{
    public NormalWave(EnemyFactory factory, int count)
    {
        for (int i = 0; i < count; i++)
        {
            Add(new EnemyLeaf(factory.CreateEnemy("toad")));
        }
    }
}
