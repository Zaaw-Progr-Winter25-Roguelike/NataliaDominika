using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Input;
using UnityEngine;

public class AttackCommand : ICommand
{
    public void Execute(Enemy enemy)
    {
        enemy.PerformAction(); // wykonanie behavior
        Debug.Log($"{enemy.EnemyName} wykonuje atak!");
    }
}
