using System.Collections.Generic;
using UnityEngine; 
public abstract class Enemy
{
    public int HP { get; protected set; } = 100;

    public EnemyController Controller { get; set; }

    protected IEnemyBehavior behavior;
    protected List<IEnemyObserver> observers = new();

    public string EnemyName { get; protected set; }
    public ILoot LootDrop { get; protected set; }
    public int DropChance { get; protected set; }

    public float DistanceToPlayer { get; set; }

    public int Speed { get; protected set; } = 3;
    public IEnemyState currentState;

    public int Damage { get; protected set; } = 10;

    public void SetBehavior(IEnemyBehavior newBehavior)
    {
        behavior = newBehavior;
    }

    public void AttachObserver(IEnemyObserver observer)
    {
        observers.Add(observer);
    }

    public void Notify(string eventType)
    {
        foreach (var obs in observers)
        {
            obs.OnEnemyEvent(this, eventType);
        }
    }

    public void TakeDamage(int dmg)
    {
        if (HP <= 0) return;

        HP -= dmg;
        if (HP < 0) HP = 0;

        Notify("HP_CHANGED"); 

        if (HP <= 0)
        {
            Notify("DEAD");
            if (Controller != null) Controller.Die();
        }
        else
        {
            if (Controller != null) Controller.PlayHitAnimation();
        }
    }

    public void AddHP(int amount)
    {
        HP += amount;
        Notify("HP_CHANGED");
    }

    public virtual void PerformAction()
    {
        behavior?.ExecuteBehavior();
    }

    public abstract void Display();

    public void ChangeState(IEnemyState newState)
    {
        currentState?.Exit(this);
        currentState = newState;
        currentState?.Enter(this);
    }

    public void UpdateState()
    {
        currentState?.Update(this);
    }
}