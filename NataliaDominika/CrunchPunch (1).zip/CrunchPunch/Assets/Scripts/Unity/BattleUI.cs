using UnityEngine;
using TMPro;
using System.Collections;

public class BattleUI : MonoBehaviour
{
    public TextMeshProUGUI hpText;
    public TextMeshProUGUI mpText;
    public TextMeshProUGUI xpText;
    public TextMeshProUGUI strategyText;

    public static BattleUI instance;

    void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            instance = this;
        }
    }

    void Start()
    {
        if (strategyText != null) strategyText.text = "";
    }

    public void UpdateHP(int currentHP)
    {
        if (hpText != null) hpText.text = "HP: " + currentHP;
    }

    public void UpdateMP(int currentMP)
    {
        if (mpText != null) mpText.text = "Mana: " + currentMP;
    }

    public void UpdateXP(int currentXP)
    {
        if (xpText != null) xpText.text = "XP: " + currentXP;
    }

    public void ShowStrategyInfo(string strategyName)
    {
        if (strategyText != null)
        {
            StopAllCoroutines();
            StartCoroutine(DisplayStrategyRoutine(strategyName));
        }
    }

    IEnumerator DisplayStrategyRoutine(string text)
    {
        strategyText.text = "Strategy: " + text;
        strategyText.gameObject.SetActive(true);
        yield return new WaitForSeconds(3f);
        strategyText.text = "";
        strategyText.gameObject.SetActive(false);
    }
}