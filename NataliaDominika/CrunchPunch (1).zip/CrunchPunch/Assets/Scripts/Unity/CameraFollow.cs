using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public float smoothSpeed = 5f;
    public float yPosition = 0f;
    public float minX;
    public float maxX;

    Transform target;
    GameManager gm;

    void Start()
    {
        gm = FindObjectOfType<GameManager>();
    }

    void LateUpdate()
    {
        if (target == null)
        {
            if (gm.activePlayer != null)
            {
                target = gm.activePlayer.transform;
            }
            else
            {
                return; 
            }
        }
        float clampedX = Mathf.Clamp(target.position.x, minX, maxX);

        Vector3 newPos = new Vector3(
            clampedX,
            yPosition,
            transform.position.z
        );

        transform.position = Vector3.Lerp(
            transform.position,
            newPos,
            smoothSpeed * Time.deltaTime
        );
    }
}