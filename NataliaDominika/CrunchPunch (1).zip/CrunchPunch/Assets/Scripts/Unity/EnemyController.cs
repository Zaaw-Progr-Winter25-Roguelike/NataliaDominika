using UnityEngine;
using TMPro;

public class EnemyController : MonoBehaviour
{
    public Enemy logicData;

    public float stopDistance = 1.2f;
    public bool spriteFaceRight = true;

    public GameObject lootPrefab; 

    public TextMeshProUGUI hpText;
    public EnemyHPBar hpBar;

    public int attackDamage = 10;

    private Transform playerTransform;
    private Animator anim;
    private SpriteRenderer spriteRenderer;
    private Rigidbody2D rb;
    private Collider2D col; 
    private bool isDead = false;

    private int currentHealth = 50;
    private int maxHealth;

    public void InitializeEnemy(Enemy enemyData)
    {
        logicData = enemyData;
        logicData.Controller = this;

        currentHealth = 50;
        maxHealth = 50;

        UpdateHPUI();

        if (logicData.currentState == null) logicData.ChangeState(new IdleState());
    }

    void Start()
    {
        anim = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>(); 

        if (maxHealth == 0) maxHealth = currentHealth;

        GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
        if (playerObj != null) playerTransform = playerObj.transform;

        if (hpText == null) hpText = GetComponentInChildren<TextMeshProUGUI>();
        if (hpBar == null) hpBar = GetComponentInChildren<EnemyHPBar>();

        UpdateHPUI();
    }

    void Update()
    {
        if (isDead) return;
        if (logicData == null || playerTransform == null) return;

        if (!playerTransform.CompareTag("Player"))
        {
            if (anim != null) anim.SetBool("IsWalking", false);
            return;
        }

        logicData.DistanceToPlayer = Vector2.Distance(transform.position, playerTransform.position);
        logicData.UpdateState();
    }

    public void TakeDamage(int damage)
    {
        if (isDead) return;

        currentHealth -= damage;
        UpdateHPUI();

        if (anim != null) anim.SetTrigger("Hit");

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void UpdateHPUI()
    {
        if (hpText != null) hpText.text = "HP: " + currentHealth;
        if (hpBar != null) hpBar.UpdateHealth(Mathf.Max(currentHealth, 0), maxHealth);
    }

    public void Die()
    {
        if (isDead) return;
        isDead = true;
        this.gameObject.tag = "Untagged";

        if (rb != null) rb.simulated = false;
        if (col != null) col.enabled = false;

        if (hpText != null) hpText.gameObject.SetActive(false);
        if (hpBar != null) hpBar.gameObject.SetActive(false);

        // Animacja
        if (anim != null) anim.SetTrigger("Death");

        if (lootPrefab != null)
        {
            Vector3 spawnPos = transform.position;
            spawnPos.y += 0.5f;

            spawnPos.z = 0f;

            Instantiate(lootPrefab, spawnPos, Quaternion.identity);
        }
        this.enabled = false;
        Destroy(gameObject, 3f);
    }

    public void MoveTowardsPlayer()
    {
        if (isDead || playerTransform == null) return;
        if (logicData.DistanceToPlayer > stopDistance)
        {
            Vector3 direction = (playerTransform.position - transform.position).normalized;
            transform.position += direction * logicData.Speed * Time.deltaTime;
            HandleFlip(direction.x);
            if (anim != null) anim.SetBool("IsWalking", true);
        }
        else
        {
            if (anim != null) anim.SetBool("IsWalking", false);
        }
    }

    public void StopMoving()
    {
        if (anim != null) anim.SetBool("IsWalking", false);
    }

    public void PerformAttack()
    {
        if (anim != null) anim.SetTrigger("Attack");

        if (playerTransform != null && Vector2.Distance(transform.position, playerTransform.position) <= stopDistance + 0.5f)
        {
            PlayerCombat playerCombat = playerTransform.GetComponent<PlayerCombat>();
            if (playerCombat != null)
            {
                playerCombat.TakeDamage(attackDamage);
            }
        }
    }

    void HandleFlip(float directionX)
    {
        if (spriteRenderer != null)
        {
            if (directionX > 0) spriteRenderer.flipX = !spriteFaceRight;
            else if (directionX < 0) spriteRenderer.flipX = spriteFaceRight;
        }
    }

    public void PlayHitAnimation()
    {
        if (anim != null) anim.SetTrigger("Hit");
    }

    public void RunAwayFromPlayer()
    {
        if (isDead || playerTransform == null) return;
        Vector3 direction = (transform.position - playerTransform.position).normalized;
        transform.position += direction * logicData.Speed * Time.deltaTime;
        HandleFlip(direction.x);
        if (anim != null) anim.SetBool("IsWalking", true);
    }
}