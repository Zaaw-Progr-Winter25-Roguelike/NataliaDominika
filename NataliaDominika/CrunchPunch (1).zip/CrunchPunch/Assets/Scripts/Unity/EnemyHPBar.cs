using UnityEngine;
using UnityEngine.UI; 
public class EnemyHPBar : MonoBehaviour
{
    public Image barImage;
    public Sprite[] healthSprites;

    public void UpdateHealth(int currentHP, int maxHP)
    {
        if (healthSprites.Length == 0) return;

        float healthPercent = (float)currentHP / maxHP;

        healthPercent = Mathf.Clamp01(healthPercent);

        int spriteIndex = Mathf.RoundToInt(healthPercent * (healthSprites.Length - 1));

        if (barImage != null)
        {
            barImage.sprite = healthSprites[spriteIndex];
            barImage.enabled = (currentHP > 0);
        }
    }
}