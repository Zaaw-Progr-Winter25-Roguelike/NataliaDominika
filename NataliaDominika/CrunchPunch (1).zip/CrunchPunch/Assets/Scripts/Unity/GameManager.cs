using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // Lista prefab�w postaci do wylosowania
    public GameObject[] players;

    // Punkt startowy
    public Transform spawnPoint;

    public GameObject activePlayer;

    void Start()
    {
        if (players.Length == 0 || spawnPoint == null)
        {
            Debug.LogError("Brakuje prefab�w lub SpawnPointu w GameManager");
            return;
        }

        int index = Random.Range(0, players.Length);

        activePlayer = Instantiate(players[index], spawnPoint.position, Quaternion.identity);

        activePlayer.tag = "Player";
        activePlayer.name = players[index].name;
    }
}