using UnityEngine;
using System.Collections.Generic;

public class LevelGenerator : MonoBehaviour
{
    [Header("T�a")]
    public GameObject mountainBackgroundPrefab;
    public GameObject woodsBackgroundPrefab;

    [Header("Gracz")]
    public GameObject playerPrefab; 
    public Transform playerSpawnPoint;

    [Header("Wrogowie")]
    public List<EnemyMapping> mountainEnemies;
    public List<EnemyMapping> woodsEnemies;

    public Transform enemySpawnPoint;

    [System.Serializable]
    public struct EnemyMapping
    {
        public string id;     
        public GameObject prefab; 
    }

    private EnemyFactory currentEnemyFactory;

    void Start()
    {
        GenerateLevel();
    }

    void GenerateLevel()
    {
        int biome = Random.Range(0, 2);
        string chosenEnemyType = "";
        //GameObject generatedBg = null;

        if (biome == 0) // G�RY
        {
            Instantiate(mountainBackgroundPrefab, Vector3.zero, Quaternion.identity);

            currentEnemyFactory = new MountainEnemyFactory();

            string[] availableTypes = { "caveharpy", "roc", "stonehidetroll" };
            chosenEnemyType = availableTypes[Random.Range(0, availableTypes.Length)];

            SpawnEnemy(chosenEnemyType, mountainEnemies);
        }
        else // LAS
        {
            Instantiate(woodsBackgroundPrefab, Vector3.zero, Quaternion.identity);

            currentEnemyFactory = new WoodsEnemyFactory();

            string[] availableTypes = { "treanthorror", "mossgoblin", "werewolf" };
            chosenEnemyType = availableTypes[Random.Range(0, availableTypes.Length)];

            SpawnEnemy(chosenEnemyType, woodsEnemies);
        }

        if (playerPrefab != null)
        {
            GameObject p = Instantiate(playerPrefab, playerSpawnPoint.position, Quaternion.identity);
            p.tag = "Player"; 
        }
    }

    void SpawnEnemy(string subtype, List<EnemyMapping> mappings)
    {
        Enemy enemyLogic = currentEnemyFactory.CreateEnemy(subtype);

        GameObject prefabToSpawn = null;
        foreach (var map in mappings)
        {
            if (map.id == subtype)
            {
                prefabToSpawn = map.prefab;
                break;
            }
        }

        if (prefabToSpawn != null)
        {
            GameObject enemyObj = Instantiate(prefabToSpawn, enemySpawnPoint.position, Quaternion.identity);

            EnemyController controller = enemyObj.GetComponent<EnemyController>();
            if (controller == null) controller = enemyObj.AddComponent<EnemyController>();

            controller.InitializeEnemy(enemyLogic);
        }
        else
        {
            Debug.LogError("Nie znaleziono prefaba dla wroga: " + subtype);
        }
    }
}