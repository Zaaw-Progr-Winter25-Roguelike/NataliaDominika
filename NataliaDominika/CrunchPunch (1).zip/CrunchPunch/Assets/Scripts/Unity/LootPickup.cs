using UnityEngine;
public enum LootType
{
    Eyeball,
    Fangs,
    Feathers,
    RootCore,
    RuneStone,
    Worms
}

public class LootPickup : MonoBehaviour
{
    [Header("Co to za przedmiot?")]
    public LootType type;

    private ILoot myLootLogic;
    private bool isCollected = false;
    private Collider2D myCollider;
    private SpriteRenderer myRenderer;

    void Start()
    {
        myCollider = GetComponent<Collider2D>();
        myRenderer = GetComponent<SpriteRenderer>();

        switch (type)
        {
            case LootType.Eyeball: myLootLogic = new Eyeball(); break;
            case LootType.Fangs: myLootLogic = new Fangs(); break;
            case LootType.Feathers: myLootLogic = new Feathers(); break;
            case LootType.RootCore: myLootLogic = new RootCore(); break;
            case LootType.RuneStone: myLootLogic = new RuneStone(); break;
            case LootType.Worms: myLootLogic = new Worms(); break;
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (isCollected) return;

        if (collision.gameObject.CompareTag("Player"))
        {
            PlayerCombat player = collision.gameObject.GetComponent<PlayerCombat>();

            if (player != null && myLootLogic != null)
            {
                isCollected = true;

                if (myCollider != null) myCollider.enabled = false;
                if (myRenderer != null) myRenderer.enabled = false;

                player.CollectLootReward(myLootLogic.XP, myLootLogic.Name);

                Debug.Log($"ZEBRANO: {myLootLogic.Name} | +{myLootLogic.XP} XP");

                Destroy(gameObject, 0.1f);
            }
        }
    }
}