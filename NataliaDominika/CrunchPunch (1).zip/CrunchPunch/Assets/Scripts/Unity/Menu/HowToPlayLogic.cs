using UnityEngine;
using UnityEngine.SceneManagement;

public class HowToPlayLogic : MonoBehaviour
{
    public void BackToMainMenu()
    {
        SceneManager.LoadScene("MenuScene");
    }
}