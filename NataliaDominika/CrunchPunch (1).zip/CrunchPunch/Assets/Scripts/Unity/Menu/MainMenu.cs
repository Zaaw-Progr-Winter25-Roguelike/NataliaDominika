using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("GamePlayScene");
    }
    public void OpenHowToPlay()
    {
        SceneManager.LoadScene("HowToPlayScene");
    }
    public void QuitGame()
    {
        Debug.Log("Wychodzenie z gry");

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}