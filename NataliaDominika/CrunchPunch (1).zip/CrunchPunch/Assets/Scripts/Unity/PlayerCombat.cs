using UnityEngine;
using System.Collections; 

public class PlayerCombat : MonoBehaviour
{
    [Header("Konfiguracja Startowa")]
    public int startHP = 100;
    public int startMP = 50;

    [Header("Walka")]
    public Transform attackPoint;
    public float attackRange = 0.8f;
    public LayerMask enemyLayers;
    public PlayerStatusText statusTextComponent;

    [Header("Ustawienia Umiej�tno�ci")]

    // Ile sekund trwa efekt?
    public float skillDuration = 10f;

    // Co ile sekund mo�na u�y� ponownie? 
    public float frenzyCooldown = 25f;
    public float holyCooldown = 25f;
    public float manaCooldown = 25f;

    private float nextFrenzyAvailable = 0f;
    private float nextHolyAvailable = 0f;
    private float nextManaAvailable = 0f;

    private bool isFrenzyActive = false;
    private bool isHolyActive = false;
    private bool isManaActive = false;

    private Character rpgCharacter;
    private HPMPXPObserver uiObserver;
    private Animator anim;

    void Start()
    {
        anim = GetComponent<Animator>();
        string myName = gameObject.name.Replace("(Clone)", "").Trim();
        if (statusTextComponent == null) statusTextComponent = GetComponentInChildren<PlayerStatusText>();

        rpgCharacter = new PlayableCharacter(myName, startHP, startMP);
        uiObserver = new HPMPXPObserver();
        rpgCharacter.AttachObserver(uiObserver);

        ChangeStrategy(new MightyFistStrategy(), "Mighty Fist");
        UpdateUnityUI();
    }

    void Update()
    {
        if (Time.timeScale == 0) return;
        if (rpgCharacter != null) rpgCharacter.OnTick();

        // Atak
        if (Input.GetKeyDown(KeyCode.Space)) PerformAttackLogic();

        // Strategie
        if (Input.GetKeyDown(KeyCode.Alpha1)) ChangeStrategy(new MightyFistStrategy(), "Mighty Fist");
        if (Input.GetKeyDown(KeyCode.Alpha2)) ChangeStrategy(new SwiftBladeStrategy(), "Swift Blade");
        if (Input.GetKeyDown(KeyCode.Alpha3)) ChangeStrategy(new SmokeScreenStrategy(), "Smoke Screen");

        HandleSkills();
    }

    void HandleSkills()
    {
        // [F]renzy Mode
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (Time.time >= nextFrenzyAvailable && !isFrenzyActive)
            {
                StartCoroutine(FrenzyRoutine());
                nextFrenzyAvailable = Time.time + frenzyCooldown;
            }
            else if (isFrenzyActive) ShowPopup("FRENZY MODE!!!!!!", Color.gray);
            else ShowPopup($"{nextFrenzyAvailable - Time.time:F1}s", Color.yellow);
        }

        // [H]oly Aura 
        if (Input.GetKeyDown(KeyCode.H))
        {
            if (Time.time >= nextHolyAvailable && !isHolyActive)
            {
                StartCoroutine(HolyAuraRoutine());
                nextHolyAvailable = Time.time + holyCooldown;
            }
            else if (isHolyActive) ShowPopup("AURA IS ACTIVE", Color.gray);
            else ShowPopup($"{nextHolyAvailable - Time.time:F1}s", Color.yellow);
        }

        // [M]ana Regen
        if (Input.GetKeyDown(KeyCode.M))
        {
            if (Time.time >= nextManaAvailable && !isManaActive)
            {
                StartCoroutine(ManaRegenRoutine());
                nextManaAvailable = Time.time + manaCooldown;
            }
            else if (isManaActive) ShowPopup("MANA REGEN ACTIVE", Color.gray);
            else ShowPopup($"{nextManaAvailable - Time.time:F1}s", Color.yellow);
        }
    }

    IEnumerator FrenzyRoutine()
    {
        isFrenzyActive = true;
        rpgCharacter = new FrenzyMode(rpgCharacter); 
        ShowPopup("FRENZY MODE START (10s)", Color.red);
        UpdateUnityUI();

        yield return new WaitForSeconds(skillDuration);

        RemoveDecoratorLogic(typeof(FrenzyMode)); 
        isFrenzyActive = false;
        ShowPopup("END OF FRENZY MODE", Color.gray);
        UpdateUnityUI();
    }

    IEnumerator HolyAuraRoutine()
    {
        isHolyActive = true;
        rpgCharacter = new HolyAura(rpgCharacter);
        ShowPopup("HEALING START (10s)", Color.green);
        UpdateUnityUI();

        yield return new WaitForSeconds(skillDuration);

        RemoveDecoratorLogic(typeof(HolyAura));
        isHolyActive = false;
        ShowPopup("END OF HOLY AURA", Color.gray);
        UpdateUnityUI();
    }

    IEnumerator ManaRegenRoutine()
    {
        isManaActive = true;
        rpgCharacter = new ManaRegenUpdate(rpgCharacter);
        ShowPopup("REGEN MANA START (10s)", Color.blue);
        UpdateUnityUI();

        yield return new WaitForSeconds(skillDuration);

        RemoveDecoratorLogic(typeof(ManaRegenUpdate));
        isManaActive = false;
        ShowPopup("END OF REGEN", Color.gray);
        UpdateUnityUI();
    }

    void RemoveDecoratorLogic(System.Type typeToRemove)
    {
        rpgCharacter = RemoveDecoratorRecursive(rpgCharacter, typeToRemove);
    }

    Character RemoveDecoratorRecursive(Character current, System.Type typeToRemove)
    {
        if (current.GetType() == typeToRemove)
            return ((CharacterDecorator)current).GetBaseCharacter();

        if (current is CharacterDecorator decorator)
        {
            Character inner = decorator.GetBaseCharacter();
            decorator.SetBaseCharacter(RemoveDecoratorRecursive(inner, typeToRemove));
            return decorator;
        }
        return current;
    }

    void PerformAttackLogic()
    {
        if (anim != null) anim.SetTrigger("Attack");
        int damage = rpgCharacter.PerformAttack();
        UpdateUnityUI();

        if (damage <= 0 || attackPoint == null) return;

        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayers);
        foreach (Collider2D enemy in hitEnemies)
        {
            EnemyController script = enemy.GetComponent<EnemyController>();
            if (script != null) script.TakeDamage(damage);
        }
    }

    public void TakeDamage(int damage)
    {
        if (!enabled || rpgCharacter.HP <= 0) return;
        rpgCharacter.TakeDamage(damage);
        ShowPopup($"-{damage}", Color.red);
        UpdateUnityUI();
        if (rpgCharacter.HP <= 0) Die();
        else if (anim != null) { anim.ResetTrigger("Hit"); anim.SetTrigger("Hit"); }
    }

    void Die()
    {
        if (!enabled) return;
        gameObject.tag = "Untagged";
        if (anim != null) { anim.ResetTrigger("Hit"); anim.SetBool("IsDead", true); anim.SetTrigger("Death"); }
        var mv = GetComponent<PlayerMovement>(); if (mv) mv.enabled = false;
        var rb = GetComponent<Rigidbody2D>(); if (rb) { rb.velocity = Vector2.zero; rb.bodyType = RigidbodyType2D.Kinematic; }
        enabled = false;
    }

    void ShowPopup(string t, Color c) { if (statusTextComponent) statusTextComponent.ShowInfo(t, c); }
    void ChangeStrategy(ICombatStrategy s, string n) { rpgCharacter.SetStrategy(s); if (BattleUI.instance) BattleUI.instance.ShowStrategyInfo(n); }
    void UpdateUnityUI() { if (BattleUI.instance) { BattleUI.instance.UpdateHP(Mathf.Max(rpgCharacter.HP, 0)); BattleUI.instance.UpdateMP(rpgCharacter.MP); BattleUI.instance.UpdateXP(rpgCharacter.XP); } }
    void OnDrawGizmosSelected() { if (attackPoint) { Gizmos.color = Color.red; Gizmos.DrawWireSphere(attackPoint.position, attackRange); } }

    public void CollectLootReward(int xpAmount, string itemName)
    {
        if (rpgCharacter != null)
        {
            rpgCharacter.GainXP(xpAmount);
        }

        ShowPopup($"+{xpAmount} XP ({itemName})", Color.yellow);

        UpdateUnityUI();
    }
}