using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float walkSpeed = 3f;
    public float runSpeed = 7f;
    private float currentSpeed;

    private bool facingRight = true;
    Rigidbody2D rb;
    Animator anim;
    float moveInput;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        gameObject.tag = "Player";
    }

    void Update()
    {
        if (!gameObject.CompareTag("Player"))
        {
            rb.velocity = Vector2.zero;
            return;
        }

        moveInput = Input.GetAxisRaw("Horizontal");

        if (Input.GetKey(KeyCode.LeftShift) && moveInput != 0)
            currentSpeed = runSpeed;
        else
            currentSpeed = walkSpeed;

        if (anim != null)
            anim.SetFloat("Speed", Mathf.Abs(rb.velocity.x));

        if (moveInput > 0 && !facingRight) Flip();
        else if (moveInput < 0 && facingRight) Flip();
    }

    void FixedUpdate()
    {
        if (!gameObject.CompareTag("Player")) return;
        rb.velocity = new Vector2(moveInput * currentSpeed, rb.velocity.y);
    }

    void Flip()
    {
        facingRight = !facingRight;
        Vector3 scaler = transform.localScale;
        scaler.x *= -1;
        transform.localScale = scaler;
    }
}