using UnityEngine;
using TMPro;

public class PlayerNameUI : MonoBehaviour
{
    public float displayTime = 5f;
    private TextMeshProUGUI textComponent;
    private GameManager gm;

    void Start()
    {
        textComponent = GetComponent<TextMeshProUGUI>();
        gm = FindObjectOfType<GameManager>();

        textComponent.text = "";
    }

    void Update()
    {
        if (gm != null && gm.activePlayer != null && textComponent.text == "")
        {
            SetPlayerName();
            Destroy(gameObject, displayTime); 
        }
    }

    void SetPlayerName()
    {
        string rawName = gm.activePlayer.name;

        string cleanName = rawName.Replace("(Clone)", "").Replace("Prefab", "").Trim();

        cleanName = System.Text.RegularExpressions.Regex.Replace(cleanName, "([a-z])([A-Z])", "$1 $2");

        textComponent.text = "PLAYER: " + cleanName;
    }
}