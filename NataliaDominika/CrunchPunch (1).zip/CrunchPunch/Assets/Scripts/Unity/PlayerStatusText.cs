using UnityEngine;
using TMPro;
using System.Collections;

public class PlayerStatusText : MonoBehaviour
{
    private TextMeshPro textMesh;
    private Vector3 originalPosition;
    private Vector3 startScale;

    void Awake()
    {
        textMesh = GetComponent<TextMeshPro>();
        originalPosition = transform.localPosition;
        startScale = transform.localScale;
    }

    void Start()
    {
        if (textMesh != null) textMesh.text = "";
    }

    void LateUpdate()
    {
        transform.rotation = Quaternion.identity;
        if (transform.parent != null && transform.parent.lossyScale.x < 0)
        {
            transform.localScale = new Vector3(-Mathf.Abs(startScale.x), startScale.y, startScale.z);
        }
        else
        {
            transform.localScale = new Vector3(Mathf.Abs(startScale.x), startScale.y, startScale.z);
        }
    }

    public void ShowInfo(string message, Color color)
    {
        if (textMesh == null) return;

        textMesh.text = message;
        textMesh.color = color;
        transform.localPosition = originalPosition;

        StopAllCoroutines();
        StartCoroutine(AnimateText());
    }

    IEnumerator AnimateText()
    {
        float duration = 2.0f;
        float elapsed = 0f;
        Vector3 startPos = originalPosition;
        Vector3 endPos = startPos + new Vector3(0, 1.0f, 0);

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            transform.localPosition = Vector3.Lerp(startPos, endPos, elapsed / duration);
            yield return null;
        }

        textMesh.text = "";
        transform.localPosition = originalPosition;
    }
}